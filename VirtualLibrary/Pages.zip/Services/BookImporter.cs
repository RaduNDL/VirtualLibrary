﻿using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using VirtualLibrary.Data;
using VirtualLibrary.Models;

namespace VirtualLibrary.Services
{
    public class BookImporter
    {
        private readonly AppDbContext _db;
        private readonly IHttpClientFactory _http;
        private readonly IWebHostEnvironment _env;
        private readonly ILogger<BookImporter> _logger;
        private readonly BookMetadataEnricher _metadataEnricher;
        private readonly BookPdfGenerator _pdfGenerator;
        private readonly Random _rng = new();

        public BookImporter(
            AppDbContext db,
            IHttpClientFactory http,
            IWebHostEnvironment env,
            ILogger<BookImporter> logger,
            BookMetadataEnricher metadataEnricher,
            BookPdfGenerator pdfGenerator)
        {
            _db = db;
            _http = http;
            _env = env;
            _logger = logger;
            _metadataEnricher = metadataEnricher;
            _pdfGenerator = pdfGenerator;
        }

        public async Task<int> ImportGoogleBooksAsync(string subject = "fiction", int total = 60)
        {
            var client = _http.CreateClient("PdfClient");

            var imported = 0;

            var supplier = await _db.Suppliers.FirstOrDefaultAsync(s => s.Name == "Open Library");
            if (supplier == null)
            {
                supplier = new Supplier
                {
                    Name = "Open Library",
                    ContactInfo = "https://openlibrary.org"
                };

                _db.Suppliers.Add(supplier);
                await _db.SaveChangesAsync();
            }

            var category = await _db.Categories.FirstOrDefaultAsync(c => c.Name == subject);
            if (category == null)
            {
                category = new Category { Name = subject };
                _db.Categories.Add(category);
                await _db.SaveChangesAsync();
            }

            var url =
                $"https://openlibrary.org/search.json?subject={Uri.EscapeDataString(subject)}&limit={total}";

            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                return 0;

            var json = await response.Content.ReadAsStringAsync();

            using var doc = JsonDocument.Parse(json);
            var books = doc.RootElement.GetProperty("docs");

            foreach (var book in books.EnumerateArray())
            {
                try
                {
                    var title = book.GetProperty("title").GetString();

                    if (string.IsNullOrWhiteSpace(title))
                        continue;

                    string? author = null;

                    if (book.TryGetProperty("author_name", out var authors) && authors.GetArrayLength() > 0)
                        author = authors[0].GetString();

                    string? isbn = null;

                    if (book.TryGetProperty("isbn", out var isbnArr) && isbnArr.GetArrayLength() > 0)
                        isbn = isbnArr[0].GetString();

                    if (!string.IsNullOrWhiteSpace(isbn) &&
                        await _db.Products.AnyAsync(p => p.Isbn == isbn))
                        continue;

                    var meta = await _metadataEnricher.GetFromGoogleBooksAsync(isbn);

                    var product = new Product
                    {
                        Title = title!,
                        Author = author,
                        Isbn = isbn,
                        Description = meta?.Description,
                        Publisher = meta?.Publisher,
                        PublishedYear = meta?.PublishedYear,
                        PageCount = meta?.PageCount,
                        Language = meta?.Language,
                        Rating = meta?.Rating,
                        Price = Math.Round((decimal)(_rng.Next(15, 100) + _rng.NextDouble()), 2),
                        CategoryId = category.CategoryId,
                        SupplierId = supplier.SupplierId,
                        CreatedAtUtc = DateTime.UtcNow
                    };

                    _db.Products.Add(product);
                    await _db.SaveChangesAsync();

                    product = await _db.Products
                        .Include(p => p.Category)
                        .Include(p => p.Supplier)
                        .FirstAsync(p => p.Id == product.Id);


                    var descPdf = await _pdfGenerator.GenerateBookDescriptionPdfAsync(product);

                    if (!string.IsNullOrWhiteSpace(descPdf))
                        product.DescriptionPdfPath = descPdf;

                    product.UpdatedAtUtc = DateTime.UtcNow;

                    await _db.SaveChangesAsync();

                    imported++;

                    _logger.LogInformation("Imported book {Title}", product.Title);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Error importing book");
                }
            }

            return imported;
        }
    }
}