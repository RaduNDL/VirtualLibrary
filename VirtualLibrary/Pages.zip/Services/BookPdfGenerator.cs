﻿using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using VirtualLibrary.Models;

namespace VirtualLibrary.Services
{
    public class BookPdfGenerator
    {
        private readonly IWebHostEnvironment _env;

        public BookPdfGenerator(IWebHostEnvironment env)
        {
            _env = env;
            QuestPDF.Settings.License = LicenseType.Community;
        }

        public async Task<string?> GenerateBookDescriptionPdfAsync(Product product)
        {
            var pdfDir = Path.Combine(_env.WebRootPath, "pdfs", "descriptions");
            Directory.CreateDirectory(pdfDir);

            var fileName = $"desc_{product.Id}_{Guid.NewGuid():N}.pdf";
            var fullPath = Path.Combine(pdfDir, fileName);

            Document.Create(container =>
            {
                container.Page(page =>
                {
                    page.Margin(40);

                    page.Header()
                        .Text("Book Description")
                        .FontSize(20)
                        .Bold();

                    page.Content().Column(col =>
                    {
                        col.Spacing(10);

                        col.Item().Text(product.Title).FontSize(18).Bold();

                        if (!string.IsNullOrWhiteSpace(product.Author))
                            col.Item().Text($"Author: {product.Author}");

                        col.Item().Text($"Category: {product.Category?.Name}");
                        col.Item().Text($"ISBN: {product.Isbn}");
                        col.Item().Text($"Publisher: {product.Publisher}");
                        col.Item().Text($"Published year: {product.PublishedYear}");
                        col.Item().Text($"Page count: {product.PageCount}");
                        col.Item().Text($"Language: {product.Language}");
                        col.Item().Text($"Rating: {product.Rating}");
                        col.Item().Text($"Price: {product.Price:0.00} RON");

                        col.Item().PaddingTop(10).Text("Description").Bold();

                        col.Item().Text(product.Description ?? "No description available.");
                    });

                    page.Footer()
                        .AlignCenter()
                        .Text("Virtual Library")
                        .FontSize(10);
                });
            })
            .GeneratePdf(fullPath);

            return Path.Combine("pdfs/descriptions", fileName).Replace('\\', '/');
        }
    }
}