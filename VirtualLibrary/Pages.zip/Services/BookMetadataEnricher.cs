﻿using System.Text.Json;

namespace VirtualLibrary.Services
{
    public class BookMetadataEnricher
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger<BookMetadataEnricher> _logger;

        public BookMetadataEnricher(
            IHttpClientFactory httpClientFactory,
            ILogger<BookMetadataEnricher> logger)
        {
            _httpClientFactory = httpClientFactory;
            _logger = logger;
        }

        public async Task<BookMetadataResult?> GetFromGoogleBooksAsync(string? isbn)
        {
            if (string.IsNullOrWhiteSpace(isbn))
                return null;

            try
            {
                var client = _httpClientFactory.CreateClient("PdfClient");
                var url = $"https://www.googleapis.com/books/v1/volumes?q=isbn:{Uri.EscapeDataString(isbn)}";

                var response = await client.GetAsync(url);
                if (!response.IsSuccessStatusCode)
                    return null;

                var json = await response.Content.ReadAsStringAsync();

                using var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;

                if (!root.TryGetProperty("items", out var items) || items.ValueKind != JsonValueKind.Array || items.GetArrayLength() == 0)
                    return null;

                var volumeInfo = items[0].GetProperty("volumeInfo");

                string? publisher = volumeInfo.TryGetProperty("publisher", out var pubProp)
                    ? pubProp.GetString()
                    : null;

                string? publishedDate = volumeInfo.TryGetProperty("publishedDate", out var pdProp)
                    ? pdProp.GetString()
                    : null;

                int? publishedYear = ParseYear(publishedDate);

                int? pageCount = null;
                if (volumeInfo.TryGetProperty("pageCount", out var pageProp) && pageProp.ValueKind == JsonValueKind.Number)
                    pageCount = pageProp.GetInt32();

                string? language = volumeInfo.TryGetProperty("language", out var langProp)
                    ? langProp.GetString()
                    : null;

                decimal? rating = null;
                if (volumeInfo.TryGetProperty("averageRating", out var ratingProp) && ratingProp.ValueKind == JsonValueKind.Number)
                    rating = Convert.ToDecimal(ratingProp.GetDouble());

                string? description = volumeInfo.TryGetProperty("description", out var descProp)
                    ? descProp.GetString()
                    : null;

                return new BookMetadataResult
                {
                    Publisher = publisher,
                    PublishedYear = publishedYear,
                    PageCount = pageCount,
                    Language = language,
                    Rating = rating,
                    Description = description
                };
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to enrich metadata from Google Books for ISBN {Isbn}", isbn);
                return null;
            }
        }

        private static int? ParseYear(string? input)
        {
            if (string.IsNullOrWhiteSpace(input) || input.Length < 4)
                return null;

            return int.TryParse(input.Substring(0, 4), out var year) ? year : null;
        }
    }
}